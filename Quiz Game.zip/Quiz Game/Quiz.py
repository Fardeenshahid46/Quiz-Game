user_password=input("Enter your password:")
if user_password=="far123":
    print("Welcome to the Quiz!")
    score=0
    correct_answers=0
    a=input("What is the capital of Pakistan?")
    if (a.capitalize()=="Islamabad"):
        print("Correct✅")
        score+=1
        correct_answers+=1
        print(f"You got{score}point")
    else:
     print("Incorrect❌")
     score-=1 
     print(f"You got{score}point")  

    
    b=input("What is the favourite dish of Pakistan?")
    if(b.capitalize()=="Biryani"):
       print("Correct✅")
       score+=1
       correct_answers+=1
       print(f"You got{score}point")     
    else:
      print("Incorrect❌") 
      score-=1 
      print(f"You got{score}point")

    c=input("What is the National animal of Pakistan?")
    if(c.capitalize()=="Markhor"):
        print("Correct✅")
        score+=1
        correct_answers+=1
        print(f"You got{score}point")
    else:
       print("Incorrect❌")
       score-=1
       print(f"You got{score}point") 
  
    d=input("What is the National Language of Pakistan?")
    if(d.capitalize()=="Urdu"):
        print("Correct✅")
        score+=1
        correct_answers+=1
        print(f"You got{score}point")
    else:
      print("Incorrect❌")           
      score-=1
      print(f"You got{score}point")
    print("Game Over‼️") 
    print("Your total score is",score,"out of 4")
    print("Your correct answers are",correct_answers,"out of 4")
    percentage=correct_answers/4*100
    print("Your percentage is:",percentage,"%")
    if(percentage>=90):
          print("You are Champion🚀")
    elif(percentage>=80):
          print("You are Perfect💯") 
    elif(percentage>=70):
      print("You are Good👍")        
    elif(percentage>=60):
      print("You are Poor👎") 
    else:
        print("You are Fail💀")        
else:
    print("Sorry You can't access Quiz!")    
    